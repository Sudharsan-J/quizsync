import { useState, useEffect } from 'react';

export function useAuth() {
    const [player, setPlayer] = useState(null);

    useEffect(() => {
        const storedPlayer = localStorage.getItem('quiz_player');
        if (storedPlayer) {
            setPlayer(JSON.parse(storedPlayer));
        }
    }, []);

    const login = (name) => {
        // Generate a random nickname (we can replace this with a better list later)
        const adjectives = ['Cosmic', 'Swift', 'Bright', 'Neon', 'Hyper', 'Super', 'Mega', 'Ultra'];
        const nouns = ['Star', 'Comet', 'Planet', 'Nebula', 'Quasar', 'Pulsar', 'Rocket', 'Orbit'];
        const nickname = `${adjectives[Math.floor(Math.random() * adjectives.length)]} ${nouns[Math.floor(Math.random() * nouns.length)]} ${Math.floor(Math.random() * 100)}`;

        const id = 'player_' + Math.random().toString(36).substr(2, 9);
        const newPlayer = {
            id,
            name, // Real name
            nickname // Anonymous nickname
        };

        localStorage.setItem('quiz_player', JSON.stringify(newPlayer));
        setPlayer(newPlayer);
        return newPlayer;
    };

    const logout = () => {
        localStorage.removeItem('quiz_player');
        setPlayer(null);
    };

    return { player, login, logout };
}
