import { Router, Route, Switch } from 'wouter';
import { useHashLocation } from 'wouter/use-location';
import { useState, useEffect } from 'react';
import { useAuth } from './hooks/useAuth.js';
import { useQuiz } from './hooks/useQuiz.js';
import { db, ref, onValue, update } from './firebase.js';
import confetti from 'canvas-confetti';

// Components
import JoinScreen from './components/JoinScreen.js';
import WaitingScreen from './components/WaitingScreen.js';
import QuestionCard from './components/QuestionCard.js';
import Leaderboard from './components/Leaderboard.js';
import HostControls from './components/HostControls.js';

const Home = () => {
    const { player, login } = useAuth();
    const { quizState, currentQuestion } = useQuiz();
    const [realtimePlayer, setRealtimePlayer] = useState(null);

    // Listen to my own player data for realtime updates (score, locked status)
    useEffect(() => {
        if (player) {
            const playerRef = ref(db, `players/${player.id}`);
            const unsubscribe = onValue(playerRef, (snapshot) => {
                setRealtimePlayer(snapshot.val());
            });
            return () => unsubscribe();
        }
    }, [player]);

    // Effect to trigger confetti if someone answers correctly (and it wasn't locked before)
    // We can listen to quizState.correctAnswerer
    useEffect(() => {
        if (quizState.correctAnswerer && quizState.questionLocked) {
            // We could show confetti for everyone or just the winner.
            // Let's show a small burst for everyone, big for winner.
            if (player && quizState.correctAnswerer.nickname === player.nickname) {
                confetti({
                    particleCount: 150,
                    spread: 70,
                    origin: { y: 0.6 }
                });
            } else {
                // Small burst for others
                /*
                confetti({
                    particleCount: 50,
                    spread: 50,
                    origin: { y: 0.6 },
                    colors: ['#ffffff', '#6366f1']
                });
                */
            }
        }
    }, [quizState.correctAnswerer, quizState.questionLocked, player]);

    const handleAnswer = async (index) => {
        if (!realtimePlayer || realtimePlayer.locked || quizState.questionLocked) return;

        const isCorrect = index === currentQuestion.correctIndex;

        if (isCorrect) {
            // Check if already locked by someone else just in case (client side check)
            const snapshot = await import('./firebase.js').then(m => m.get(m.child(m.ref(db), 'quiz/questionLocked')));
            if (snapshot.val() === true) return;

            // Mark question as locked relative to global quiz
            update(ref(db, 'quiz'), {
                questionLocked: true,
                correctAnswerer: { name: player.name, nickname: player.nickname }
            });

            // Update my score
            update(ref(db, `players/${player.id}`), {
                score: (realtimePlayer.score || 0) + 10
            });

        } else {
            // Lock myself
            update(ref(db, `players/${player.id}`), {
                locked: true
            });
            // Visual feedback? QuestionCard handles locked state.
        }
    };

    if (!player) {
        return html`<${JoinScreen} onJoin=${() => { }} />`;
    }

    if (quizState.status === 'waiting') {
        return html`<${WaitingScreen} status=${quizState.status} player=${player} />`;
    }

    if (quizState.status === 'ended') {
        return html`
            <div className="container">
                <h2 style=${{ textAlign: 'center', marginTop: '2rem' }}>Quiz Ended!</h2>
                <${Leaderboard} />
            </div>
        `;
    }

    if (quizState.status === 'active') {
        if (!currentQuestion) return html`<div className="container"><p>Loading question...</p></div>`;

        // Check if I am the winner
        const amIWinner = quizState.correctAnswerer && quizState.correctAnswerer.nickname === player.nickname;

        return html`
            <div className="container" style=${{ paddingTop: '2rem' }}>
                <div style=${{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                     <div className="glass" style=${{ padding: '0.5rem 1rem' }}>
                        👤 <strong>${player.nickname}</strong>
                     </div>
                     <div className="glass" style=${{ padding: '0.5rem 1rem' }}>
                        ⭐ <strong>${realtimePlayer?.score || 0}</strong> pts
                     </div>
                </div>

                ${quizState.questionLocked && html`
                    <div className="glass" style=${{ padding: '1rem', background: 'rgba(99, 102, 241, 0.2)', border: '1px solid #6366f1', textAlign: 'center', marginBottom: '1rem' }}>
                        <h3>✨ Correct Answer found!</h3>
                        <p>Winner: <strong>${quizState.correctAnswerer?.nickname}</strong></p>
                    </div>
                `}
                
                <${QuestionCard} 
                    question=${currentQuestion}
                    locked=${(realtimePlayer?.locked || quizState.questionLocked)}
                    onAnswer=${handleAnswer}
                />
            </div>
        `;
    }

    return html`<div>Unknown State</div>`;
};

const App = () => html`
    <${Router} hook=${useHashLocation}>
        <${Switch}>
            <${Route} path="/" component=${Home} />
            <${Route} path="/host" component=${HostControls} />
            <${Route} path="/leaderboard" component=${(props) => html`<${Leaderboard} isPublic=${true} />`} />
            <${Route}>404: No such page!</${Route}>
        </${Switch}>
    </${Router}>
`;

const root = ReactDOM.createRoot(document.getElementById('root'));
try {
    root.render(html`<${App} />`);
} catch (err) {
    document.body.innerHTML += `<div style="color:red; padding: 20px;">Runtime Error: ${err.message}</div>`;
    console.error(err);
}

// Global error handler for async issues (like Firebase config failures)
window.addEventListener('error', (event) => {
    const errorDiv = document.getElementById('error-display') || document.createElement('div');
    errorDiv.id = 'error-display';
    errorDiv.style.cssText = 'position: fixed; bottom: 0; left: 0; right: 0; background: #991b1b; color: white; padding: 1rem; z-index: 9999; text-align: center;';
    errorDiv.textContent = `Error: ${event.message}`;
    document.body.appendChild(errorDiv);
});
