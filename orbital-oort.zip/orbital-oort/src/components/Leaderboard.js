import { html } from '../utils.js';
import { usePlayers } from '../hooks/usePlayers.js';

export default function Leaderboard({ isPublic }) {
    const { players } = usePlayers();

    // Take top 10
    const topPlayers = players.slice(0, 10);

    return html`
        <div className="container" style=${{ paddingTop: '2rem' }}>
            <div className="glass" style=${{ padding: '2rem' }}>
                <h1 style=${{ textAlign: 'center', marginBottom: '2rem' }}>🏆 Leaderboard</h1>
                
                <table style=${{ width: '100%', borderCollapse: 'collapse' }}>
                    <thead>
                        <tr style=${{ borderBottom: '1px solid rgba(255,255,255,0.2)' }}>
                            <th style=${{ textAlign: 'left', padding: '1rem' }}>Rank</th>
                            <th style=${{ textAlign: 'left', padding: '1rem' }}>Player</th>
                            <th style=${{ textAlign: 'right', padding: '1rem' }}>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${topPlayers.map((p, i) => html`
                            <tr key=${p.id} style=${{
            background: i === 0 ? 'rgba(255, 215, 0, 0.1)' :
                i === 1 ? 'rgba(192, 192, 192, 0.1)' :
                    i === 2 ? 'rgba(205, 127, 50, 0.1)' : 'transparent',
            borderBottom: '1px solid rgba(255,255,255,0.05)'
        }}>
                                <td style=${{ padding: '1rem', fontWeight: 'bold' }}>#${i + 1}</td>
                                <td style=${{ padding: '1rem' }}>
                                    ${p.nickname} 
                                    ${!isPublic && html`<span style=${{ opacity: 0.5, fontSize: '0.8em', marginLeft: '0.5rem' }}>(${p.name})</span>`}
                                </td>
                                <td style=${{ padding: '1rem', textAlign: 'right', fontWeight: 'bold', color: '#6366f1' }}>${p.score}</td>
                            </tr>
                        `)}
                    </tbody>
                </table>
                
                ${players.length === 0 && html`
                    <p style=${{ textAlign: 'center', opacity: 0.5, marginTop: '2rem' }}>No players yet...</p>
                `}
            </div>
        </div>
    `;
}
