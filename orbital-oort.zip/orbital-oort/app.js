const { useState, useEffect, useRef, useCallback } = React;

// ── CONFIG ───────────────────────────────────────────────────────────────────
const firebaseConfig = {
    apiKey: "AIzaSyDG_fvHfRjUPMK0Z5CV6PxEnAUiCVe9gdg",
    authDomain: "quizsync-symposium.firebaseapp.com",
    databaseURL: "https://quizsync-symposium-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "quizsync-symposium",
    storageBucket: "quizsync-symposium.firebasestorage.app",
    messagingSenderId: "1071606099131",
    appId: "1:1071606099131:web:cfad25392ce005df31cd9e"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}
const db = firebase.database();

const ADMIN_PASSWORD = "godmode"; // Default admin password
const QUESTION_TIMER_SEC = 20; // 20 seconds per question

// ── UTILITIES ────────────────────────────────────────────────────────────────
const ADJECTIVES = ['Quick', 'Bright', 'Super', 'Hyper', 'Mega', 'Fast', 'Cool', 'Epic', 'Turbo', 'Ultra'];
const NOUNS = ['Player', 'Star', 'Hero', 'Winner', 'Champ', 'Legend', 'Rocket', 'Spark', 'Pilot', 'Racer'];
const randomNick = () => `${ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)]} ${NOUNS[Math.floor(Math.random() * NOUNS.length)]} ${Math.floor(Math.random() * 99) + 1}`;

function launchConfetti() {
    const canvas = document.getElementById('confetti-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const colors = ['#3b82f6', '#60a5fa', '#2563eb', '#ffffff', '#0ea5e9'];
    const particles = Array.from({ length: 150 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height - canvas.height, // Start above
        size: Math.random() * 8 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedY: Math.random() * 5 + 2,
        speedX: (Math.random() - 0.5) * 4,
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 10
    }));

    let animationFrame;
    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        let active = false;

        particles.forEach(p => {
            if (p.y < canvas.height + 100) {
                p.y += p.speedY;
                p.x += p.speedX;
                p.rotation += p.rotationSpeed;
                p.speedY += 0.05; // Gravity

                ctx.save();
                ctx.translate(p.x, p.y);
                ctx.rotate((p.rotation * Math.PI) / 180);
                ctx.fillStyle = p.color;
                ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
                ctx.restore();

                active = true;
            }
        });

        if (active) animationFrame = requestAnimationFrame(animate);
    }
    animate();
}

const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
function playSound(type) {
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (type === 'success') {
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
        osc.frequency.exponentialRampToValueAtTime(1174.66, audioCtx.currentTime + 0.1); // D6
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.5);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.5);
    } else if (type === 'error') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, audioCtx.currentTime);
        osc.frequency.linearRampToValueAtTime(100, audioCtx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
        gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
    } else if (type === 'click') {
        osc.frequency.setValueAtTime(800, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
    } else if (type === 'joined') {
        osc.frequency.setValueAtTime(440, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.05, audioCtx.currentTime);
        gain.gain.linearRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
    }
}

// ── HOOKS ────────────────────────────────────────────────────────────────────
function useQuizState() {
    const [state, setState] = useState(null); // start as null aka loading
    useEffect(() => {
        const ref = db.ref('quiz');
        const listener = ref.on('value', s => {
            const val = s.val();
            // Ensure default values exist to prevent crashes
            setState(val || { status: 'waiting', currentQuestionIndex: -1, questionLocked: false, correctAnswerer: null, startTime: 0 });
        });
        return () => ref.off('value', listener);
    }, []);
    return state;
}

function useList(path, sortFn) {
    const [list, setList] = useState([]);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        const ref = db.ref(path);
        const listener = ref.on('value', s => {
            const data = s.val();
            const arr = data ? Object.entries(data).map(([id, val]) => ({ id, ...val })) : [];
            if (sortFn) arr.sort(sortFn);
            setList(arr);
            setLoading(false);
        });
        return () => ref.off('value', listener);
    }, [path]);
    return { data: list, loading };
}

function useServerTime() {
    const [offset, setOffset] = useState(0);
    useEffect(() => {
        const ref = db.ref('.info/serverTimeOffset');
        ref.once('value', s => setOffset(s.val() || 0));
    }, []);
    return Date.now() + offset;
}

// ── COMPONENTS ───────────────────────────────────────────────────────────────

function Nav({ active, validPages, onChange }) {
    return (
        <nav className="nav">
            <div className="brand">
                <span style={{ color: 'var(--primary)', fontSize: '1.2em' }}>⚡</span>
                Quiz<span style={{ color: 'var(--accent)' }}>Sync</span>
            </div>
            <div className="nav-links">
                {validPages.map(p => (
                    <div key={p.id}
                        className={`nav-item ${active === p.id ? 'active' : ''}`}
                        onClick={() => onChange(p.id)}>
                        {p.label}
                    </div>
                ))}
            </div>
        </nav>
    );
}

function LoadingScreen({ msg = "Loading..." }) {
    return (
        <div className="container" style={{ height: '80vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <div className="spinner" style={{ marginBottom: '1rem' }}></div>
            <p style={{ color: 'var(--text-muted)' }}>{msg}</p>
        </div>
    );
}

function Landing({ onNavigate }) {
    const quiz = useQuizState();
    const { data: players } = useList('players');

    if (!quiz) return <LoadingScreen msg="Connecting to Hub..." />;

    return (
        <div className="container hero-grid fade-in-up">
            <div className="hero-main">
                <div style={{ marginBottom: '1rem', display: 'inline-flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(255,255,255,0.05)', padding: '0.5rem 1rem', borderRadius: '50px', border: '1px solid var(--glass-border)' }}>
                    <span className="pulse" style={{ width: 8, height: 8, background: quiz.status === 'active' ? 'var(--success)' : 'var(--text-muted)', borderRadius: '50%' }}></span>
                    <span style={{ fontSize: '0.9rem', fontWeight: 600, color: 'var(--text-muted)' }}>{quiz.status.toUpperCase()} • {players.length} PLAYERS ONLINE</span>
                </div>
                <h1 style={{ fontSize: 'clamp(3rem, 8vw, 6rem)', marginBottom: '0.5rem', fontWeight: 800, letterSpacing: '-0.05em', lineHeight: 1 }}>
                    QUIZSYNC
                </h1>
                <p style={{ fontSize: '1.1rem', color: 'var(--text-muted)', maxWidth: '500px', margin: '0 auto 2.5rem' }}>
                    Join the realtime quiz. Compete with others and check the live leaderboard.
                </p>
                <button className="btn btn-glow pulse" style={{ fontSize: '1.1rem', padding: '1rem 2.5rem' }} onClick={() => onNavigate('player')}>
                    Join Quiz →
                </button>
            </div>

            <div className="card hero-card delay-1" style={{ cursor: 'pointer' }} onClick={() => onNavigate('player')}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🎮</div>
                <div>
                    <h3>Play</h3>
                    <p style={{ color: 'var(--text-muted)', marginTop: '0.5rem' }}>Enter your name and join.</p>
                </div>
                <div style={{ marginTop: '1.5rem', textAlign: 'right', color: 'var(--primary)', fontWeight: 700 }}>Go →</div>
            </div>

            <div className="card hero-card delay-2" style={{ cursor: 'pointer' }} onClick={() => onNavigate('leaderboard')}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>🏆</div>
                <div>
                    <h3>Leaderboard</h3>
                    <p style={{ color: 'var(--text-muted)', marginTop: '0.5rem' }}>See top scores.</p>
                </div>
                <div style={{ marginTop: '1.5rem', textAlign: 'right', color: 'var(--primary)', fontWeight: 700 }}>View →</div>
            </div>

            <div className="card hero-card delay-3" style={{ cursor: 'pointer' }} onClick={() => onNavigate('admin')}>
                <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>⚙️</div>
                <div>
                    <h3>Host Panel</h3>
                    <p style={{ color: 'var(--text-muted)', marginTop: '0.5rem' }}>Manage quiz.</p>
                </div>
                <div style={{ marginTop: '1.5rem', textAlign: 'right', color: 'var(--text)', fontWeight: 700 }}>Login →</div>
            </div>
        </div>
    );
}

function PlayerView({ player, setPlayer, onBack }) {
    const quiz = useQuizState();
    const { data: questions, loading: qLoading } = useList('questions', (a, b) => a.order - b.order);
    const [me, setMe] = useState(null);
    const [timeLeft, setTimeLeft] = useState(QUESTION_TIMER_SEC);
    const [offset, setOffset] = useState(0);

    // Sync Time
    useEffect(() => {
        db.ref('.info/serverTimeOffset').once('value', s => setOffset(s.val() || 0));
    }, []);

    // Timer Logic
    useEffect(() => {
        if (!quiz || quiz.status !== 'active' || quiz.questionLocked) {
            setTimeLeft(0);
            return;
        }

        const interval = setInterval(() => {
            const now = Date.now() + offset;
            const startTime = quiz.startTime || now;
            const elapsed = Math.floor((now - startTime) / 1000);
            const remaining = Math.max(0, QUESTION_TIMER_SEC - elapsed);
            setTimeLeft(remaining);

            // Auto-lock on timeout (client-side visual only, server enforcement is better)
            if (remaining === 0 && !quiz.questionLocked) {
                // Could auto-submit emptiness or just lock locally
            }
        }, 1000);
        return () => clearInterval(interval);
    }, [quiz, offset]);


    useEffect(() => {
        if (!player?.id) return;
        return db.ref(`players/${player.id}`).on('value', s => setMe(s.val()));
    }, [player?.id]);

    const [loading, setLoading] = useState(false);
    const [nameInput, setNameInput] = useState('');
    const [selectedOpt, setSelectedOpt] = useState(null);

    // Join
    if (!player) {
        return (
            <div className="container" style={{ maxWidth: '500px', marginTop: '10vh' }}>
                <button onClick={onBack} className="btn btn-ghost" style={{ marginBottom: '2rem' }}>← Back</button>
                <div className="card fade-in-up">
                    <h2 style={{ fontSize: '2rem', marginBottom: '1rem' }}>Enter Name</h2>
                    <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>Use your real name for the leaderboard.</p>
                    <form onSubmit={async (e) => {
                        e.preventDefault();
                        if (!nameInput.trim()) return;
                        setLoading(true);
                        const id = 'p_' + Math.random().toString(36).substr(2, 9);
                        const nick = randomNick();
                        const pData = { name: nameInput, nickname: nick, score: 0, locked: false, online: true };
                        await db.ref(`players/${id}`).set(pData);
                        localStorage.setItem('godmode_player', JSON.stringify({ id, ...pData }));
                        setPlayer({ id, ...pData });
                        setLoading(false);
                        playSound('joined');
                    }}>
                        <div className="input-group">
                            <input className="input-field" placeholder="Ex. Arjun Kumar" value={nameInput} onChange={e => setNameInput(e.target.value)} required autoFocus />
                            <div className="input-label">Real Name</div>
                        </div>
                        <button type="submit" className="btn btn-glow" style={{ width: '100%' }} disabled={loading}>
                            {loading ? 'Joining...' : 'Join Quiz'}
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    // Safety check for kicked players
    if (me === null && !loading) {
        // If me becomes null after having been set, player was kicked/deleted
        //  return <div className="container" style={{textAlign:'center'}}><h3>You have been disconnected.</h3><button className="btn btn-primary" onClick={()=>{localStorage.removeItem('godmode_player'); window.location.reload()}}>Return Home</button></div>;
    }

    if (!quiz) return (
        <div className="container" style={{ height: '80vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
            <div className="spinner" style={{ marginBottom: '1rem' }}></div>
            <p style={{ color: 'var(--text-muted)', marginBottom: '1rem' }}>Syncing Game State...</p>
            <button className="btn btn-ghost" onClick={onBack} style={{ fontSize: '0.8rem' }}>Cancel</button>
        </div>
    );

    // Waiting
    if (quiz.status === 'waiting') {
        return (
            <div className="container" style={{ maxWidth: '600px', textAlign: 'center', marginTop: '15vh' }}>
                <button className="btn btn-ghost" onClick={onBack} style={{ marginBottom: '1rem', position: 'absolute', top: '1rem', left: '1rem' }}>← Back</button>
                <div className="card fade-in-up">
                    <div className="float" style={{ fontSize: '4rem', marginBottom: '1rem' }}>⏳</div>
                    <h2 style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>Waiting for Host</h2>
                    <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>The quiz will start soon...</p>
                    <div style={{ background: 'rgba(255,255,255,0.05)', padding: '1rem', borderRadius: 'var(--radius-sm)' }}>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '2px' }}>Playing As</div>
                        <div style={{ fontSize: '1.5rem', fontWeight: 700, color: 'var(--primary-glow)', marginTop: '0.5rem' }}>{player.nickname}</div>
                    </div>
                </div>
            </div>
        );
    }

    // Ended
    if (quiz.status === 'ended') return <div className="container" style={{ marginTop: '10vh', textAlign: 'center' }}><h1 style={{ fontSize: '4rem' }}>Quiz Ended</h1><p>Check the big screen for results.</p><button className="btn btn-ghost" style={{ marginTop: '2rem' }} onClick={onBack}>Back to Home</button></div>;

    // Active
    if (qLoading) return <LoadingScreen msg="Loading Questions..." />;

    const currentQ = questions[quiz.currentQuestionIndex];
    if (!currentQ && questions.length > 0) return <div className="container" style={{ textAlign: 'center' }}><h2>Question Loading Error</h2><p>Please wait for host...</p></div>;
    if (!currentQ) return <div className="container" style={{ marginTop: '20vh', textAlign: 'center' }}><h2>No Questions Available</h2><p style={{ color: 'var(--text-muted)' }}>Waiting for host to add questions.</p></div>;

    const isLocked = me?.locked || quiz.questionLocked || timeLeft === 0;

    // Reset selection on new q
    const prevQ = useRef(null);
    if (prevQ.current !== currentQ.id) {
        setSelectedOpt(null);
        prevQ.current = currentQ.id;
    }

    const iWon = quiz.correctAnswerer?.id === player.id;

    // Auto-confetti
    useEffect(() => {
        if (iWon && quiz.questionLocked) {
            launchConfetti();
            playSound('success');
        } else if (quiz.questionLocked && !iWon) {
            // Maybe play error sound if I got it wrong?
            // Checking if I locked myself (wrong answer)
            if (me?.locked) playSound('error');
        }
    }, [iWon, quiz.questionLocked, me?.locked]);

    const handleAnswer = async (idx) => {
        if (isLocked || selectedOpt !== null) return;
        playSound('click');
        setSelectedOpt(idx);

        // Optimistic UI update could go here, but for simplicity we rely on Firebase
        if (idx === currentQ.correctIndex) {
            // Check lock status atomically-ish
            const lockSnap = await db.ref('quiz/questionLocked').get();
            if (lockSnap.val()) return;

            // Log the win
            await db.ref('quiz').update({
                questionLocked: true,
                correctAnswerer: { id: player.id, nickname: player.nickname, name: player.name }
            });
            await db.ref(`players/${player.id}`).update({ score: (me?.score || 0) + 10 });
        } else {
            await db.ref(`players/${player.id}`).update({ locked: true });
        }
    };

    return (
        <div className="container" style={{ maxWidth: '800px' }}>
            <button className="btn btn-ghost" onClick={onBack} style={{ marginBottom: '1rem', padding: '0.5rem 1rem', fontSize: '0.8rem' }}>← Leave</button>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2rem', alignItems: 'flex-end' }}>
                <div>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>PLAYER</div>
                    <div style={{ fontSize: '1.25rem', fontWeight: 700 }}>{player.nickname}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>SCORE</div>
                    <div style={{ fontSize: '2rem', fontWeight: 700, color: 'var(--primary)', lineHeight: 1 }}>{me?.score || 0}</div>
                </div>
            </div>

            {/* Timer Bar */}
            {!quiz.questionLocked && (
                <div style={{ height: 4, background: 'var(--glass-border)', borderRadius: 2, marginBottom: '2rem', overflow: 'hidden' }}>
                    <div style={{
                        height: '100%',
                        background: timeLeft < 5 ? 'var(--error)' : 'var(--primary)',
                        width: `${(timeLeft / QUESTION_TIMER_SEC) * 100}%`,
                        transition: 'width 1s linear'
                    }}></div>
                </div>
            )}

            {/* Status Banner */}
            {quiz.questionLocked && (
                <div className={`card ${iWon ? 'pulse' : ''}`} style={{ marginBottom: '2rem', background: iWon ? 'rgba(16, 185, 129, 0.2)' : 'rgba(255,255,255,0.05)', borderColor: iWon ? 'var(--success)' : 'var(--glass-border)' }}>
                    <h3 style={{ color: iWon ? 'var(--success)' : 'var(--text)' }}>
                        {iWon ? 'Correct! (+10 pts)' :
                            quiz.correctAnswerer ? `${quiz.correctAnswerer.nickname} Won this round` :
                                'Time Up / No Winner'}
                    </h3>
                </div>
            )}
            {me?.locked && !quiz.questionLocked && <div className="card" style={{ borderColor: 'var(--error)', color: 'var(--error)', marginBottom: '2rem' }}>Wrong Answer - Locked</div>}


            <div className="card" style={{ padding: '2rem 1.5rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                    <div style={{ color: 'var(--primary)', fontWeight: 700, letterSpacing: '1px' }}>QUESTION {quiz.currentQuestionIndex + 1} OF {questions.length}</div>
                    <div style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>{timeLeft}s</div>
                </div>

                <h2 style={{ fontSize: '1.5rem', marginBottom: '2rem', lineHeight: 1.4 }}>{currentQ.text}</h2>
                <div>
                    {currentQ.options.map((opt, i) => {
                        let statusClass = '';
                        if (selectedOpt === i) statusClass = 'selected';
                        if (quiz.questionLocked) {
                            if (i === currentQ.correctIndex) statusClass = 'correct';
                            else if (selectedOpt === i) statusClass = 'wrong';
                        }

                        return (
                            <button key={i} className={`option-btn ${statusClass}`} onClick={() => handleAnswer(i)} disabled={isLocked}>
                                <div className="option-key">{String.fromCharCode(65 + i)}</div>
                                <div>{opt}</div>
                            </button>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}

function AdminView({ onBack }) {
    const [auth, setAuth] = useState(sessionStorage.getItem('godmode_auth') === 'true');
    const [pwd, setPwd] = useState('');
    const quiz = useQuizState();
    const { data: questions, loading: qLoading } = useList('questions', (a, b) => a.order - b.order);
    const { data: players, loading: pLoading } = useList('players', (a, b) => (b.score || 0) - (a.score || 0));

    // Create / Manage inputs
    const [newQ, setNewQ] = useState({ text: '', options: ['', '', '', ''], correctIndex: 0 });

    if (!auth) {
        return (
            <div className="modal-backdrop">
                <div className="card" style={{ maxWidth: '400px', width: '100%', textAlign: 'center' }}>
                    <h2>Admin Access</h2>
                    <p style={{ color: 'var(--text-muted)', marginBottom: '2rem' }}>Enter password.</p>
                    <form onSubmit={e => {
                        e.preventDefault();
                        if (pwd === ADMIN_PASSWORD) {
                            sessionStorage.setItem('godmode_auth', 'true');
                            setAuth(true);
                        } else alert('Incorrect Password');
                    }}>
                        <div className="input-group">
                            <input type="password" text-align="center" className="input-field" value={pwd} onChange={e => setPwd(e.target.value)} autoFocus />
                        </div>
                        <button className="btn btn-glow" style={{ width: '100%' }}>Login</button>
                    </form>
                    <button className="btn btn-ghost" style={{ width: '100%', marginTop: '1rem' }} onClick={onBack}>Cancel</button>
                </div>
            </div>
        );
    }

    if (!quiz || qLoading || pLoading) return <LoadingScreen msg="Loading Dashboard..." />;

    const resetGame = async () => {
        if (!confirm('WARNING: Reset all scores and game state?')) return;
        await db.ref('quiz').set({ status: 'waiting', currentQuestionIndex: -1, questionLocked: false, correctAnswerer: null });
        const pSnap = await db.ref('players').get();
        if (pSnap.val()) {
            const updates = {};
            Object.keys(pSnap.val()).forEach(k => {
                updates[`players/${k}/score`] = 0;
                updates[`players/${k}/locked`] = false;
            });
            await db.ref().update(updates);
        }
    };

    const kickPlayer = async (pid) => {
        if (confirm('Kick this player?')) {
            await db.ref(`players/${pid}`).remove();
        }
    };

    return (
        <div className="container">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <button className="btn btn-ghost" onClick={onBack}>← Back</button>
                <div className="badge" style={{ background: 'var(--primary)', color: 'white', padding: '0.5rem 1rem', borderRadius: '50px' }}>Host Panel</div>
            </div>

            <div className="hero-grid" style={{ marginTop: 0 }}>
                {/* Controls */}
                <div className="hero-main" style={{ gridColumn: 'span 4', textAlign: 'left', padding: 0 }}>
                    <div className="card" style={{ height: '100%' }}>
                        <h3>Dashboard</h3>
                        <div style={{ marginTop: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <div style={{ background: 'rgba(255,255,255,0.05)', padding: '1rem', borderRadius: 8 }}>
                                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>STATUS</div>
                                <div style={{ fontSize: '1.2rem', fontWeight: 700 }}>{quiz.status.toUpperCase()}</div>
                            </div>

                            {quiz.status === 'waiting' && <button className="btn btn-glow" onClick={() => {
                                if (questions.length === 0) return alert('Please add questions before starting!');
                                db.ref('quiz').update({
                                    status: 'active',
                                    currentQuestionIndex: 0,
                                    startTime: firebase.database.ServerValue.TIMESTAMP
                                });
                            }}>Start Quiz</button>}

                            {quiz.status === 'active' && (
                                <>
                                    <button className="btn btn-primary" onClick={async () => {
                                        const next = quiz.currentQuestionIndex + 1;
                                        if (next >= questions.length) {
                                            db.ref('quiz').update({ status: 'ended' });
                                        } else {
                                            // Reset locks
                                            const updates = {
                                                'quiz/currentQuestionIndex': next,
                                                'quiz/questionLocked': false,
                                                'quiz/correctAnswerer': null,
                                                'quiz/startTime': firebase.database.ServerValue.TIMESTAMP
                                            };
                                            const pSnap = await db.ref('players').get();
                                            if (pSnap.val()) Object.keys(pSnap.val()).forEach(k => updates[`players/${k}/locked`] = false);
                                            db.ref().update(updates);
                                        }
                                    }}>Next Question →</button>
                                    <button className="btn btn-ghost" style={{ borderColor: 'var(--error)', color: 'var(--error)' }} onClick={() => db.ref('quiz').update({ status: 'ended' })}>End Quiz</button>
                                </>
                            )}

                            <button className="btn btn-ghost" onClick={resetGame}>Reset Quiz</button>

                            <hr style={{ borderColor: 'var(--glass-border)', margin: '1rem 0' }} />

                            <button className="btn btn-ghost" style={{ fontSize: '0.8rem' }} onClick={async () => {
                                try {
                                    await db.ref('connection_test').set({ timestamp: Date.now() });
                                    const snap = await db.ref('connection_test').get();
                                    if (snap.exists()) {
                                        alert('✅ Firebase Connection HEALTHY! Read/Write works.');
                                        db.ref('connection_test').remove();
                                    } else {
                                        alert('⚠️ Write succeeded but Read failed? Check rules.');
                                    }
                                } catch (e) {
                                    alert('❌ CONNECTION FAILED: ' + e.message + '\n\nPlease check your Firebase Console > Realtime Database > Rules.\nMake sure they are set to ".read": true, ".write": true');
                                }
                            }}>🛠️ Test Database Connection</button>
                        </div>

                        <div style={{ marginTop: '2rem' }}>
                            <h4>Players ({players.length})</h4>
                            <div style={{ maxHeight: '200px', overflowY: 'auto', marginTop: '1rem' }}>
                                {players.map(p => (
                                    <div key={p.id} style={{ padding: '0.5rem', display: 'flex', justifyContent: 'space-between', background: 'rgba(0,0,0,0.2)', marginBottom: '5px', borderRadius: '4px' }}>
                                        <span>{p.nickname}</span>
                                        <span style={{ color: 'var(--error)', cursor: 'pointer', fontWeight: 'bold' }} onClick={() => kickPlayer(p.id)}>×</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* Question Manager */}
                <div className="hero-main" style={{ gridColumn: 'span 8', padding: 0, textAlign: 'left' }}>
                    <div className="card">
                        <h3>Add Question</h3>
                        <form onSubmit={async e => {
                            e.preventDefault();
                            if (newQ.options.some(o => !o)) return alert('Missing options');
                            db.ref('questions').push({ ...newQ, order: questions.length });
                            setNewQ({ text: '', options: ['', '', '', ''], correctIndex: 0 });
                        }} style={{ marginTop: '2rem' }}>
                            <div className="input-group">
                                <input className="input-field" placeholder="Question Text" value={newQ.text} onChange={e => setNewQ({ ...newQ, text: e.target.value })} required />
                            </div>
                            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
                                {newQ.options.map((o, i) => (
                                    <div key={i} style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                                        <input type="radio" checked={newQ.correctIndex === i} onChange={() => setNewQ({ ...newQ, correctIndex: i })} />
                                        <input className="input-field" placeholder={`Option ${String.fromCharCode(65 + i)}`} value={o} onChange={e => {
                                            const ops = [...newQ.options]; ops[i] = e.target.value;
                                            setNewQ({ ...newQ, options: ops });
                                        }} required />
                                    </div>
                                ))}
                            </div>
                            <button className="btn btn-ghost" style={{ width: '100%', marginTop: '1rem' }}>Add Question</button>
                        </form>

                        <div style={{ marginTop: '2rem' }}>
                            <h4>Questions ({questions.length})</h4>
                            {questions.map((q, i) => (
                                <div key={q.id} style={{ padding: '0.5rem', borderBottom: '1px solid var(--glass-border)', display: 'flex', justifyContent: 'space-between' }}>
                                    <span>{i + 1}. {q.text}</span>
                                    <span style={{ color: 'var(--error)', cursor: 'pointer' }} onClick={() => { if (confirm('Delete?')) db.ref(`questions/${q.id}`).remove(); }}>×</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

function Leaderboard({ isPublic }) {
    const { data: players, loading } = useList('players', (a, b) => (b.score || 0) - (a.score || 0));

    if (loading) return <LoadingScreen msg="Loading Ranks..." />;

    return (
        <div className="container" style={{ maxWidth: '800px' }}>
            <div className="card fade-in-up">
                <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
                    <div style={{ fontSize: '3rem' }}>🏆</div>
                    <h2 style={{ fontSize: '2.5rem' }}>Leaderboard</h2>
                </div>
                <div>
                    {players.map((p, i) => (
                        <div key={p.id} className="lb-item">
                            <div className={`lb-rank top-${i + 1}`}>{i + 1}</div>
                            <div style={{ marginLeft: '1rem' }}>
                                <div style={{ fontWeight: 700, fontSize: '1.2rem' }}>{p.nickname}</div>
                                {!isPublic && <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{p.name}</div>}
                            </div>
                            <div className="lb-score">{p.score || 0}</div>
                        </div>
                    ))}
                    {players.length === 0 && <div style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No players yet.</div>}
                </div>
            </div>
        </div>
    );
}

// ── ROOT ─────────────────────────────────────────────────────────────────────
function App() {
    const [page, setPage] = useState('landing');
    const [player, setPlayer] = useState(() => {
        try { return JSON.parse(localStorage.getItem('godmode_player')); } catch { return null; }
    });

    const validPages = [
        { id: 'landing', label: 'Home' },
        { id: 'player', label: 'Play' },
        { id: 'leaderboard', label: 'Board' },
        { id: 'admin', label: 'Host' },
    ];

    let content;
    switch (page) {
        case 'landing': content = <Landing onNavigate={setPage} />; break;
        case 'player': content = <PlayerView player={player} setPlayer={setPlayer} onBack={() => setPage('landing')} />; break;
        case 'leaderboard': content = <Leaderboard isPublic={true} />; break;
        case 'admin': content = <AdminView onBack={() => setPage('landing')} />; break;
        default: content = <Landing onNavigate={setPage} />;
    }

    return (
        <>
            <Nav active={page} validPages={validPages} onChange={setPage} />
            {content}
        </>
    );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
