import { useState } from 'react';
import { html } from '../utils.js';
import { useAuth } from '../hooks/useAuth.js';
import { db, ref, set } from '../firebase.js';

export default function JoinScreen({ onJoin }) {
    const [name, setName] = useState('');
    const { login } = useAuth();
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!name.trim()) return;

        setIsSubmitting(true);
        const player = login(name);

        // Sync to Firebase
        // We set initial score to 0 and online to true
        await set(ref(db, `players/${player.id}`), {
            name: player.name,
            nickname: player.nickname,
            score: 0,
            locked: false,
            online: true
        });

        if (onJoin) onJoin();
        setIsSubmitting(false);
    };

    return html`
        <div className="container" style=${{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
            <div className="glass" style=${{ padding: '3rem', width: '100%', maxWidth: '400px', textAlign: 'center' }}>
                <h1 style=${{ marginBottom: '2rem', background: 'linear-gradient(to right, #6366f1, #ec4899)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
                    Symposium Quiz
                </h1>
                <form onSubmit=${handleSubmit}>
                    <div style=${{ marginBottom: '1.5rem' }}>
                        <label style=${{ display: 'block', marginBottom: '0.5rem', textAlign: 'left' }}>Enter your name</label>
                        <input 
                            type="text" 
                            value=${name}
                            onChange=${(e) => setName(e.target.value)}
                            placeholder="John Doe"
                            style=${{
            width: '100%',
            padding: '1rem',
            borderRadius: '8px',
            border: '1px solid rgba(255,255,255,0.2)',
            background: 'rgba(0,0,0,0.2)',
            color: 'white',
            fontSize: '1.1rem'
        }}
                            required
                        />
                    </div>
                    <button 
                        type="submit" 
                        className="btn btn-primary" 
                        style=${{ width: '100%', fontSize: '1.2rem' }}
                        disabled=${isSubmitting}
                    >
                        ${isSubmitting ? 'Joining...' : 'Join Quiz'}
                    </button>
                    <p style=${{ marginTop: '1rem', fontSize: '0.9rem', opacity: 0.7 }}>
                        You will be assigned an anonymous nickname.
                    </p>
                </form>
            </div>
        </div>
    `;
}
