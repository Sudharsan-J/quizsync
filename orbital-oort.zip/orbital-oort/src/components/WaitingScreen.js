import { html } from '../utils.js';

export default function WaitingScreen({ status, player }) {
    return html`
        <div className="container" style=${{ textAlign: 'center', paddingTop: '10vh' }}>
            <div className="glass" style=${{ padding: '3rem', display: 'inline-block' }}>
                <div style=${{
            width: '80px',
            height: '80px',
            margin: '0 auto 2rem',
            border: '4px solid rgba(255,255,255,0.1)',
            borderTopColor: '#6366f1',
            borderRadius: '50%',
            animation: 'spin 1s linear infinite'
        }}></div>
                <style>
                    ${`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}
                </style>
                <h2>Waiting for Host</h2>
                <p style=${{ fontSize: '1.2rem', opacity: 0.8, marginBottom: '2rem' }}>
                    The quiz will start shortly.
                </p>
                <div style=${{ padding: '1rem', background: 'rgba(255,255,255,0.05)', borderRadius: '8px' }}>
                    <p style=${{ margin: 0 }}>You are playing as:</p>
                    <h3 style=${{ margin: '0.5rem 0 0', color: '#ec4899' }}>${player?.nickname}</h3>
                </div>
            </div>
        </div>
    `;
}
