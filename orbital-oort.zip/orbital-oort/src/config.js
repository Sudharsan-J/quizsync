// Firebase Configuration
export const firebaseConfig = {
    apiKey: "AIzaSyDG_fvHfRjUPMK0Z5CV6PxEnAUiCVe9gdg",
    authDomain: "quizsync-symposium.firebaseapp.com",
    databaseURL: "https://quizsync-symposium-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "quizsync-symposium",
    storageBucket: "quizsync-symposium.firebasestorage.app",
    messagingSenderId: "1071606099131",
    appId: "1:1071606099131:web:cfad25392ce005df31cd9e"
};