import { useState, useEffect } from 'react';
import { html } from '../utils.js';
import { useQuiz } from '../hooks/useQuiz.js';
import { usePlayers } from '../hooks/usePlayers.js';
import { db, ref, update, push, set } from '../firebase.js';

export default function HostControls() {
    const { quizState, questions, currentQuestion } = useQuiz();
    const { players } = usePlayers();
    const [newQuestion, setNewQuestion] = useState({
        text: '',
        options: ['', '', '', ''],
        correctIndex: 0
    });

    const startQuiz = () => {
        update(ref(db, 'quiz'), {
            status: 'active',
            currentQuestionIndex: 0,
            questionLocked: false,
            correctAnswerer: null
        });
    };

    const nextQuestion = () => {
        const nextIndex = quizState.currentQuestionIndex + 1;
        if (nextIndex < questions.length) {
            update(ref(db, 'quiz'), {
                currentQuestionIndex: nextIndex,
                questionLocked: false,
                correctAnswerer: null
            });
            // Reset player locks
            // This requires cloud functions or iterating through all players.
            // Client-side iteration is fine for small-scale (symposium).
            players.forEach(p => {
                update(ref(db, `players/${p.id}`), {
                    locked: false
                });
            });
        } else {
            endQuiz();
        }
    };

    const endQuiz = () => {
        update(ref(db, 'quiz'), {
            status: 'ended'
        });
    };

    const addQuestion = (e) => {
        e.preventDefault();
        const questionsRef = ref(db, 'questions');
        const newRef = push(questionsRef);
        set(newRef, {
            ...newQuestion,
            order: questions.length
        });
        setNewQuestion({ text: '', options: ['', '', '', ''], correctIndex: 0 });
    };

    const updateOption = (index, value) => {
        const newOptions = [...newQuestion.options];
        newOptions[index] = value;
        setNewQuestion({ ...newQuestion, options: newOptions });
    };

    return html`
        <div className="container" style=${{ paddingTop: '2rem' }}>
            <div className="glass" style=${{ padding: '2rem', marginBottom: '2rem' }}>
                <h2>Host Control Panel</h2>
                <div style=${{ display: 'flex', gap: '1rem', alignItems: 'center', marginBottom: '1rem' }}>
                    <div className="status-badge">Status: <strong>${quizState.status}</strong></div>
                    <div className="status-badge">Players: <strong>${players.length}</strong></div>
                    <div className="status-badge">Question: <strong>${quizState.currentQuestionIndex + 1} / ${questions.length}</strong></div>
                </div>

                <div style=${{ display: 'flex', gap: '1rem' }}>
                    <button className="btn btn-primary" onClick=${startQuiz} disabled=${quizState.status === 'active'}>Start Quiz</button>
                    <button className="btn btn-primary" onClick=${nextQuestion} disabled=${quizState.status !== 'active'}>Next Question</button>
                    <button className="btn" style=${{ background: '#ef4444', color: 'white' }} onClick=${endQuiz}>End Quiz</button>
                </div>
            </div>

            <div style=${{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
                <div className="glass" style=${{ padding: '2rem' }}>
                    <h3>Add Question</h3>
                    <form onSubmit=${addQuestion}>
                        <div style=${{ marginBottom: '1rem' }}>
                            <label style=${{ display: 'block', marginBottom: '0.5rem' }}>Question Text</label>
                            <input 
                                type="text" 
                                style=${{ width: '100%', padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc', color: '#000' }}
                                value=${newQuestion.text}
                                onChange=${(e) => setNewQuestion({ ...newQuestion, text: e.target.value })}
                                required
                            />
                        </div>
                        <div style=${{ marginBottom: '1rem' }}>
                            <label style=${{ display: 'block', marginBottom: '0.5rem' }}>Options</label>
                            ${newQuestion.options.map((opt, i) => html`
                                <div key=${i} style=${{ marginBottom: '0.5rem', display: 'flex', gap: '0.5rem' }}>
                                    <input 
                                        type="text" 
                                        placeholder=${`Option ${i + 1}`}
                                        style=${{ flex: 1, padding: '0.5rem', borderRadius: '4px', border: '1px solid #ccc', color: '#000' }}
                                        value=${opt}
                                        onChange=${(e) => updateOption(i, e.target.value)}
                                        required
                                    />
                                    <input 
                                        type="radio" 
                                        name="correctIndex" 
                                        checked=${newQuestion.correctIndex === i} 
                                        onChange=${() => setNewQuestion({ ...newQuestion, correctIndex: i })}
                                    />
                                </div>
                            `)}
                        </div>
                        <button type="submit" className="btn btn-primary">Add Question</button>
                    </form>
                </div>

                <div className="glass" style=${{ padding: '2rem' }}>
                    <h3>Review Questions</h3>
                    <ul style=${{ listStyle: 'none', padding: 0 }}>
                        ${questions.map((q, i) => html`
                            <li key=${i} style=${{ marginBottom: '1rem', padding: '0.5rem', background: 'rgba(255,255,255,0.05)', borderRadius: '8px' }}>
                                <strong>${i + 1}. ${q.text}</strong>
                                <br />
                                <small>Correct: ${q.options[q.correctIndex]}</small>
                            </li>
                        `)}
                    </ul>
                </div>
            </div>
            
            <div className="glass" style=${{ padding: '2rem', marginTop: '2rem' }}>
                 <h3>Active Players</h3>
                 <ul style=${{ columns: 2 }}>
                    ${players.map(p => html`
                        <li key=${p.id}>${p.name} (${p.nickname}) - ${p.score} pts</li>
                    `)}
                 </ul>
            </div>
        </div>
    `;
}
