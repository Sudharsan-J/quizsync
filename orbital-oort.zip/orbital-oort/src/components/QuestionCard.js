import { html } from '../utils.js';
import { useAuth } from '../hooks/useAuth.js'; // To get player ID
import { db, ref, update, push, set } from '../firebase.js';

export default function QuestionCard({ question, locked, onAnswer }) {
    if (!question) return html`<div>Loading question...</div>`;

    const handleOptionClick = (index) => {
        if (locked) return;
        onAnswer(index);
    };

    return html`
        <div className="glass" style=${{ padding: '2rem', maxWidth: '800px', margin: '0 auto' }}>
            <h2 style=${{ marginBottom: '2rem', fontSize: '1.5rem', lineHeight: '1.4' }}>${question.text}</h2>
            
            <div style=${{ display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
                ${question.options.map((opt, i) => html`
                    <button 
                        key=${i}
                        className="btn"
                        style=${{
            textAlign: 'left',
            background: locked ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.1)',
            border: '1px solid rgba(255,255,255,0.1)',
            cursor: locked ? 'not-allowed' : 'pointer',
            opacity: locked ? 0.6 : 1,
            position: 'relative',
            overflow: 'hidden'
        }}
                        onClick=${() => handleOptionClick(i)}
                        disabled=${locked}
                    >
                        <span style=${{ fontWeight: 'bold', marginRight: '1rem', opacity: 0.7 }}>${String.fromCharCode(65 + i)}</span>
                        ${opt}
                    </button>
                `)}
            </div>

            ${locked && html`
                <div style=${{ marginTop: '1.5rem', padding: '1rem', background: 'rgba(0,0,0,0.2)', borderRadius: '8px', textAlign: 'center' }}>
                    🔒 Answer locked. Waiting for result...
                </div>
            `}
        </div>
    `;
}
