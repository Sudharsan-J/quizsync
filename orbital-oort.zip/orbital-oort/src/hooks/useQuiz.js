import { useState, useEffect } from 'react';
import { db, ref, onValue } from '../firebase.js';

export function useQuiz() {
    const [quizState, setQuizState] = useState({
        status: 'waiting', // waiting, active, ended
        currentQuestionIndex: -1,
        questionLocked: false,
        correctAnswerer: null
    });

    const [currentQuestion, setCurrentQuestion] = useState(null);
    const [questions, setQuestions] = useState([]);

    useEffect(() => {
        const quizRef = ref(db, 'quiz');
        const unsubscribe = onValue(quizRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                setQuizState(data);
            }
        });

        // Also listen to questions to get the current one
        const questionsRef = ref(db, 'questions');
        const unsubscribeQuestions = onValue(questionsRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                const qList = Object.values(data).sort((a, b) => a.order - b.order); // Assuming order field
                setQuestions(qList);
            } else {
                setQuestions([]);
            }
        });

        return () => {
            unsubscribe();
            unsubscribeQuestions();
        };
    }, []);

    // Derived state
    useEffect(() => {
        if (quizState.currentQuestionIndex >= 0 && questions.length > quizState.currentQuestionIndex) {
            setCurrentQuestion(questions[quizState.currentQuestionIndex]);
        } else {
            setCurrentQuestion(null);
        }
    }, [quizState.currentQuestionIndex, questions]);

    return { quizState, currentQuestion, questions };
}
