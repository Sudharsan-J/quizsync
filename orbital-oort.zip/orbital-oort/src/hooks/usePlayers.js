import { useState, useEffect } from 'react';
import { db, ref, onValue } from '../firebase.js';

export function usePlayers() {
    const [players, setPlayers] = useState([]);

    useEffect(() => {
        const playersRef = ref(db, 'players');
        const unsubscribe = onValue(playersRef, (snapshot) => {
            const data = snapshot.val();
            if (data) {
                // Convert object to array
                const playerList = Object.entries(data).map(([key, value]) => ({
                    id: key,
                    ...value
                }));
                // Sort by score descending
                playerList.sort((a, b) => b.score - a.score);
                setPlayers(playerList);
            } else {
                setPlayers([]);
            }
        });

        return () => unsubscribe();
    }, []);

    return { players };
}
