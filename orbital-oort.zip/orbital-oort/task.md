# Task: Mentimeter-Inspired QuizSync Rewrite

- [/] Write complete index.html (CSS design system, all components)
- [ ] Verify file syntax is valid (no JSX errors, no duplicate declarations)
- [ ] Verify all Firebase paths are room-scoped
- [ ] Verify question add formKey fix is wired
